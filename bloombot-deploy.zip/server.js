const express = require('express');
const path = require('path');
const app = express();

// Configuration pour Vercel & production
const PORT = process.env.PORT || 3000;
const __dirname = path.dirname(new URL(import.meta.url).pathname);

// Middleware de sécurité
app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'SAMEORIGIN');
    res.setHeader('Cache-Control', 'public, max-age=3600');
    next();
});

// Servir les fichiers statiques
app.use(express.static(__dirname, {
    maxAge: '1h',
    etag: true
}));

// Route racine
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Routes pour fichiers avec extensions
app.get('/:file', (req, res, next) => {
    const filePath = path.join(__dirname, req.params.file);
    res.sendFile(filePath, (err) => {
        if (err) next();
    });
});

// Fallback - redirect tout vers index.html pour SPA support
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Démarrer le serveur
app.listen(PORT, '0.0.0.0', () => {
    console.log(`✅ BloomBot actif sur port ${PORT}`);
});
